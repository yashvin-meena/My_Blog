from django.contrib.auth.forms import UserCreationForm,UsernameField,AuthenticationForm
from django import forms
from .models import Blogs
from django.contrib.auth.models import User

class LoginForm(AuthenticationForm):
    username = UsernameField(widget=forms.TextInput(attrs={'class':'form-control','placeholder':'Username'}))
    password = forms.CharField(strip=False,widget=forms.PasswordInput(attrs={'class':'form-control mt-3','placeholder':'Password'}))

class RegistrationForm(UserCreationForm):
    password1 = forms.CharField(widget=forms.PasswordInput(attrs={'class':'form-control','placeholder':'Password'}))
    password2 = forms.CharField(widget=forms.PasswordInput(attrs={'class':'form-control','placeholder':'Password(again)'}))

    class Meta:
        model = User
        fields = ['username','first_name','last_name','email']
        widgets = {
            'username':forms.TextInput(attrs={'class':"form-control",'placeholder':'Username'}),
            'first_name':forms.TextInput(attrs={'class':"form-control",'placeholder':'First Name'}),
            'last_name':forms.TextInput(attrs={'class':"form-control",'placeholder':'Last Name'}),
            'email':forms.EmailInput(attrs={'class':"form-control",'placeholder':'Email'})
        }

class CreateBlog(forms.ModelForm):
    class Meta:
        model = Blogs
        fields = '__all__'
        exclude = ['user']
        widgets = {
            'user':forms.TextInput(attrs={'class':"form-control",}),
            'title':forms.TextInput(attrs={'class':"form-control"}),
            'desc':forms.Textarea(attrs={'class':"form-control"}),
            'img':forms.FileInput(attrs={'class':"form-control"}),
        }