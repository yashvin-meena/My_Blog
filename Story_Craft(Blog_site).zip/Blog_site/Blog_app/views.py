from django.shortcuts import render, redirect
from django.contrib.auth.models import User
from django.contrib.auth import login,authenticate,logout
from django.contrib import messages
from . import forms
from .models import Blogs
from django.views.generic import DeleteView
from django.contrib.auth.decorators import login_required
from django.core.paginator import Paginator

def home(request):
    all_blogs = Blogs.objects.all().order_by('title')
    paginator = Paginator(all_blogs,4)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    context = {'blogs':page_obj}
    return render(request,'blog/index.html',context)

def signin(request):
    if not request.user.is_authenticated:
        if request.method == 'POST':
            fm = forms.LoginForm(data=request.POST,request=request)
            if fm.is_valid():
                username = fm.cleaned_data['username']
                password = fm.cleaned_data['password']
                user = authenticate(username=username,password=password)
                if user is not None:
                    login(request,user)
                    # request.session['id'] = request.user.id 
                    messages.info(request,'Logged in Successfully !!')
                    return redirect('/')
            else:
                return render(request,'blog/login.html',{'forms':fm})

        
        fm = forms.LoginForm()
        context = {'forms':fm}
        return render(request,'blog/login.html',context)
    else:
        return redirect('/')

def signup(request):
    if request.method == 'POST':
        fm = forms.RegistrationForm(request.POST)
        if fm.is_valid():
            uname = fm.cleaned_data['username']
            fname = fm.cleaned_data['first_name']
            lname = fm.cleaned_data['last_name']
            email = fm.cleaned_data['email']
            password = fm.cleaned_data['password1']
            record = User(
                username = uname,
                first_name = fname,
                last_name = lname,
                email = email,
            )
            record.set_password(password)
            record.save()
            messages.info(request,'registered Successfully !!')
            return redirect('/login/')
        else:
            return render(request,'blog/register.html',{'form':fm})


 
    fm = forms.RegistrationForm()
    context = {'form':fm}
    return render(request,'blog/register.html',context)

def logout_view(request):
    logout(request)
    return redirect('/login/')

@login_required
def createBlog(request):
    if request.method == 'POST':
        fm = forms.CreateBlog(request.POST,request.FILES)
        if fm.is_valid():
            user = request.user
            title = fm.cleaned_data['title']
            desc = fm.cleaned_data['desc']
            img = fm.cleaned_data['img']

            obj = Blogs(user = user, title = title, desc = desc, img = img)
            obj.save()
            messages.info(request,'created !!')
            return redirect('/')

    fm = forms.CreateBlog()
    context = {'forms':fm,'name':'yashvin'}
    return render(request,'blog/Addblog.html',context)

@login_required
def myBlogs(request):
    blogs = Blogs.objects.filter(user = request.user)
    a = blogs.values()
    context = {'myBlogs': blogs}
    return render(request,'blog/myblog.html',context)

def searchBlogs(request):
    query = request.GET.get('query')
    data = Blogs.objects.filter(title__icontains = query)
    context = {'blogs':data}
    return render(request,'blog/index.html',context)


class DeleteBlog(DeleteView):
    model = Blogs
    template_name = 'blog/confirm.html'
    success_url = '/Myblog/'
    pk_url_kwarg = 'id'

def readBlog(request,id):
    blog_has_to_be_read = Blogs.objects.get(pk = id)
    context = {'blog':blog_has_to_be_read}
    return render(request,'blog/readBlog.html',context)

@login_required
def editBlog(request):
    if request.method == 'POST':
        print('inside yh function')
        blog_has_to_be_edited = Blogs.objects.get(pk=2)
        edited = forms.CreateBlog(request.POST,request.FILES,instance=blog_has_to_be_edited)
        edited.save()
        messages.success(request,'Updated !!')
        return redirect('/')
    else:
        blog_has_to_be_edited = Blogs.objects.get(pk=2)
        fm = forms.CreateBlog(instance=blog_has_to_be_edited)
        context = {'forms':fm}
        print('outside the functuon')
    return render(request,'blog/editBlog.html',context)

