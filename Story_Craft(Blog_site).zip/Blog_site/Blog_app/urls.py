from django.urls import path
from . import views
urlpatterns = [
    path('',views.home,name='home'),
    path('login/',views.signin,name='login'),
    path('register/',views.signup,name='register'),
    path('logout/',views.logout_view,name='logout'),
    path('addblog/',views.createBlog,name='create'),
    path('Myblog/',views.myBlogs,name='myblog'),
    path('searchBlog/',views.searchBlogs,name='search'),
    path('deleteBlog/<int:id>',views.DeleteBlog.as_view(),name='delete'),
    path('readBlog/<int:id>',views.readBlog,name='read'),
    path('editBlog/',views.editBlog,name='edit'),

]